package tut7;

public class BagTest {
	public static void main(String[] args) {
		BagInterface<String> colorBag = new ArrayBag();
		System.out.println("Initial bag size: "+ colorBag.getCurrentSize());
		System.out.println("Check before adding objects isEmpty(): "+colorBag.isEmpty());
		System.out.println("Add 3 objects ... ");
		colorBag.add("blue");
		colorBag.add("red");
		colorBag.add("yellow");
		System.out.println("After adding objects isEmpty(): "+colorBag.isEmpty());
		System.out.println("Current bag size: "+colorBag.getCurrentSize());
		System.out.println("Removing 1 existing object...");
		colorBag.remove();
		System.out.println("Updated bag size: "+colorBag.getCurrentSize());
		System.out.println("Current frequency of blue: "+colorBag.getFrequencyOf("blue"));
		System.out.println("Adding 1 occurrence of blue ...");
		colorBag.add("blue");
		System.out.println("Updated frequency of blue: "+colorBag.getFrequencyOf("blue"));
		System.out.println("Checking whether bag contains red: " + colorBag.contains("red"));
		System.out.println("Removing the occurrence of red ...");
		colorBag.remove("red");
		System.out.println("Now checking whether bag still contains red: "+colorBag.contains("red"));
		System.out.println("Removing all entries from the bag...");
		colorBag.clear();
		System.out.println("Final bag size: "+colorBag.getCurrentSize());
		
		System.out.println("\n\n\n");
		
		BagInterface<String> numberBag = new ArrayBag(10);
		System.out.println("Initial bag size: "+ numberBag.getCurrentSize());
		System.out.println("Check before adding objects isEmpty(): "+numberBag.isEmpty());
		System.out.println("Add 3 objects ... ");
		numberBag.add("1");
		numberBag.add("2");
		numberBag.add("3");
		System.out.println("After adding objects isEmpty(): "+numberBag.isEmpty());
		System.out.println("Current bag size: "+numberBag.getCurrentSize());
		System.out.println("Removing 1 existing object...");
		numberBag.remove();
		System.out.println("Updated bag size: "+numberBag.getCurrentSize());
		System.out.println("Current frequency of 1: "+numberBag.getFrequencyOf("1"));
		System.out.println("Adding 1 occurrence of 1 ...");
		numberBag.add("1");
		System.out.println("Updated frequency of 1: "+numberBag.getFrequencyOf("1"));
		System.out.println("Checking whether bag contains 2: " + numberBag.contains("2"));
		System.out.println("Removing the occurrence of 2 ...");
		numberBag.remove("2");
		System.out.println("Now checking whether bag still contains 2: "+numberBag.contains("2"));
		System.out.println("Removing all entries from the bag...");
		numberBag.clear();
		System.out.println("Final bag size: "+numberBag.getCurrentSize());
	}
}
