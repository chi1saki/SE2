package to_dos.factory;

// Create the abstract class called Course
abstract class Course {
	protected int duration; //in semesters
	protected double fee; //in dollars ($)
	
	// TO-DO: Declare 2 void abstract methods: getDuration(), getFeePerSemester()
	void getDuration() {
		duration = 5;
		System.out.println("Total semesters: "+duration);
	}
	abstract void getFeePerSemester();
	
	// TO-DO: Declare void method: calculateTotalFee(). Total = duration * fee
	void calculateTotalFee() {
		System.out.println("Total fee: "+(duration*fee));
	}
}