package DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import DBConnection.DBConnect;
import Model.Band;
/*
 * This is a DAO (DATA ACCESS OBJECT) class which provides
 * CRUS(CREATE - READ - UPDATE - DELETE) database operations
 * for the table Band in the database
 */
public class BandDAO {
	public BandDAO() {
		
	}
	public List<Band> selectAllBand(){
		List<Band> bands = new ArrayList<>();
		//Step 1: Establishing the connection
		Connection connection = DBConnect.getConnection();
		try {
			//Step 2: Create a statement using connection object
			String SELECT_ALL_BANDS = "SELECT * FROM Band";
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_BANDS);
			//Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();
			//Step 4: Process the ResultSet object
			while(rs.next()) {
				int Band_ID = rs.getInt("Band_ID");
				String Star_band = rs.getString("Star_band");
				bands.add(new Band(Band_ID, Star_band));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return bands;
	}
}
