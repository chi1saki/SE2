package to_dos.abstract_factory;

/* Create ShapeFactory class extending AbstractFactory to generate 
 * object of concrete class based on given information. 
 */

public class ShapeFactory extends AbstractFactory {
	// TO-DO: Implement the getShape() method
	@Override
	public Shape getShape(String shapeType) {
		switch(shapeType){
                    case "Rectangle":
                        return new Rectangle();
                        
                    case "Square":
                        return new Square();
                     
                    default:
                        return null;
                }
	}
}
