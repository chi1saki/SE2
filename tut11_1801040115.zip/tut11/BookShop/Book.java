/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tut11.BookShop;

/**
 *
 * @author Win 8.1 Version 2
 */
public class Book {
    private String title;
    private String author;
    private double price;

    public Book(String title, String author, double price) {
        this.setTitle(title);
        this.setAuthor(author);
        this.setPrice(price);
    }
    
    protected String getAuthor() {
        return this.author;
    }
    protected void setAuthor(String author) throws IllegalArgumentException{
        //TODO: Validate as it is written in Constraints
        String[] s = author.split(" ");
        if(s.length==2){
            if(s[2].charAt(0)>='0' && s[2].charAt(0)<='9'){
                throw new IllegalArgumentException("Author not valid!");
            }
        }
        this.author = author;
    }
    protected String getTitle() {
        return this.title;
    }
    protected void setTitle(String title) throws IllegalArgumentException{
        if (title.length() < 3) {
            throw new IllegalArgumentException("Title not valid!");
        }
        this.title = title;
    }
    protected double getPrice() {
        return this.price;
    }
    protected void setPrice(double price) throws IllegalArgumentException{
        if (price < 1) {
            throw new IllegalArgumentException("Price not valid!");
        }
        this.price = price;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("Type: ").append(this.getClass().getSimpleName())
                .append(System.lineSeparator())
                .append("Title: ").append(this.getTitle())
                .append(System.lineSeparator())
                .append("Author: ").append(this.getAuthor())
                .append(System.lineSeparator())
                .append("Price: ").append(this.getPrice())
                .append(System.lineSeparator());
        return sb.toString();
    }
}
