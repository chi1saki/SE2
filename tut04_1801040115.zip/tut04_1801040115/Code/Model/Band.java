package Model;
/*
 * This is a model class represents a Band entity for the table Band in the database
 */
public class Band {
	protected int Band_ID;
	protected String Star_band;
	
	public Band() {
		
	}
	public Band(String Star_band){
		super();
		this.Star_band=Star_band;
	}
	public Band(int Band_ID, String Star_band) {
		super();
		this.Band_ID=Band_ID;
		this.Star_band=Star_band;
	}
	public int getBand_ID() {
		return Band_ID;
	}
	public String getStar_band() {
		return Star_band;
	}
	public void setBand_ID() {
		this.Band_ID=Band_ID;
	}
	public void setStar_band() {
		this.Star_band=Star_band;
	}
	
}
