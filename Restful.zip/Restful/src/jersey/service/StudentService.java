package jersey.service;
import java.util.ArrayList;
import java.util.List;
import jersey.model.Student;
public class StudentService {
	public List<Student> getAllStudents() {
		Student s1 = new Student (1,"Trung Kien", "0914914065");
		Student s2 = new Student (2,"Minh Hieu", "0986868686");
		List<Student> list = new ArrayList<Student>();
		list.add(s1);
		list.add(s2);
		return list;
	}

}
