package to_dos.abstract_factory;

// Create the Shape interface
public interface Shape {
	void draw();
}
