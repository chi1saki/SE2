package Model;
/*
 * This is a model class represents a Star entity for the table Star in database
 */
public class Star {
	protected int Star_ID;
	protected String Star_name;
	protected String Star_band;
	protected String Star_Company;
	
	public Star() {
		
	}
	public Star(String Star_name, String Star_band, String Star_Company) {
		super();
		this.Star_name=Star_name;
		this.Star_band=Star_band;
		this.Star_Company=Star_Company;
	}
	public Star(int Star_ID, String Star_name, String Star_band, String Star_Company) {
		super();
		this.Star_ID=Star_ID;
		this.Star_name=Star_name;
		this.Star_band=Star_band;
		this.Star_Company=Star_Company;
	}
	
	public int getStar_ID() {
		return Star_ID;
	}
	public String getStar_name() {
		return Star_name;
	}
	public String getStar_band() {
		return Star_band;
	}
	public String getStar_Company() {
		return Star_Company;
	}
	public void setStar_ID() {
		this.Star_ID=Star_ID;
	}
	public void setStar_name() {
		this.Star_name=Star_name;
	}
	public void setStar_band() {
		this.Star_band=Star_band;
	}
	public void setStar_Company() {
		this.Star_Company=Star_Company;
	}

}
