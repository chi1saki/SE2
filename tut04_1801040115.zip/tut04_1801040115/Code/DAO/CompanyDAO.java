package DAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import DBConnection.DBConnect;
import Model.Company;
/*
 * This is a DAO(DATA ACCESS OBJECT) class which provides
 * CRUD (CREATE - READ - UPDATE - DELETE) database operations
 * for the table Company in the database
 */
public class CompanyDAO {
	public CompanyDAO() {
		
	}
	public List<Company> selectAllCompany(){
		List<Company>company = new ArrayList<>();
		//Step 1: Establishing a connection
		Connection connection = DBConnect.getConnection();
		try {
			//Step 2: Create a statement using connection object
			String SELECT_ALL_COMP = "SELECT * FROM Company";
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_COMP);
			//Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();
			//Step 4: Process the ResultSet object
			while(rs.next()) {
				int Company_ID = rs.getInt("Company_ID");
				String Star_Company = rs.getString("Star_Company");
				company.add(new Company(Company_ID, Star_Company));
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return company;
	}

}
