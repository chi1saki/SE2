package Model;
/*
 * This is a model class which represents a Company entity for Company table in database 
 */
public class Company {
	protected int Company_ID;
	protected String Star_Company;
	
	public Company() {
		
	}
	public Company(String Star_Company) {
		super();
		this.Star_Company=Star_Company;
	}
	public Company(int Company_ID, String Star_Company) {
		super();
		this.Company_ID=Company_ID;
		this.Star_Company=Star_Company;
	}
	public int getCompany_ID() {
		return Company_ID;
	}
	public String getStar_Company() {
		return Star_Company;
	}
	public void setCompany_ID() {
		this.Company_ID=Company_ID;
	}
	public void setStar_Company() {
		this.Star_Company=Star_Company;
	}
	
}
